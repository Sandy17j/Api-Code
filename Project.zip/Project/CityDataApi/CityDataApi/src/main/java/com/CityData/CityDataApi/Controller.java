package com.CityData.CityDataApi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/City")
public class Controller {
    @Autowired
    CityDetailsMumbai M;
    @Autowired
    CityDetailsDelhi D;
    private List<CityVariables> cities = new ArrayList<>();

    @GetMapping("Mumbai")
    CityVariables MumbaiCity2(){
        return M.getMumbai();
    }

    @GetMapping("Delhi")
    CityVariables Delhi(){return D.getDelhi();}

    @PostMapping
    public CityVariables addCity(@RequestBody CityVariables city) {
        cities.add(city);
        return city;
    }

    @GetMapping("{cityName}")
    public CityVariables getCityByName(@PathVariable String cityName) {
        for (CityVariables city : cities) {
            if (city.getCityName().equalsIgnoreCase(cityName)) {
                return city; // Return the city details if found
            }
        }
        throw new CityNotFoundException("City not found"); // Handle not found case
    }
    class CityNotFoundException extends RuntimeException {
        public CityNotFoundException(String message) {
            super(message);
        }}}

