package com.CityData.CityDataApi;

import org.springframework.stereotype.Component;

@Component
public class CityDetailsDelhi {

    CityVariables Delhi = new CityVariables(110045, "Delhi", "Delhi", "India", 100);


    public CityVariables getDelhi() {
        return Delhi;
    }
}
