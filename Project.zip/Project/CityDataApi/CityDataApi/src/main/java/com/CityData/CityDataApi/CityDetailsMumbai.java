package com.CityData.CityDataApi;

import org.springframework.stereotype.Component;
@Component
public class CityDetailsMumbai{

    CityVariables Mumbai = new CityVariables(110010 , "Mumbai" , "Maharashtra" , "India" , 110);


    public CityVariables getMumbai() {
        return Mumbai;
    }
}

