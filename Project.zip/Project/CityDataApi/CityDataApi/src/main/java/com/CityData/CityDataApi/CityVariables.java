package com.CityData.CityDataApi;

public class CityVariables {
    private int Pincode;
    private String CityName;
    private String State;
    private String Country;
    private int StdCode;

    public int getPincode() {
        return Pincode;
    }

    public void setPincode(int pincode) {
        Pincode = pincode;
    }

    public String getCityName() {
        return CityName;
    }

    public void setCityName(String cityName) {
        CityName = cityName;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public int getStdCode() {
        return StdCode;
    }

    public void setStdCode(int stdCode) {
        StdCode = stdCode;
    }
    public CityVariables(){}

    public CityVariables(int pincode, String cityName, String state, String country, int stdCode) {
        Pincode = pincode;
        CityName = cityName;
        State = state;
        Country = country;
        StdCode = stdCode;
    }
}
