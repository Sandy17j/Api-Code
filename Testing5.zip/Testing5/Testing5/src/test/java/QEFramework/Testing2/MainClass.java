package QEFramework.Testing2;

import org.apache.poi.xssf.usermodel.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MainClass {
//    static CheckApi capiM = new CheckApi();
    static goToSheet gts = new goToSheet();
    static String path = "C:\\Users\\atul.parashar.in\\Desktop\\Testing5\\Testing5\\src\\main\\resources\\CityData.xlsx";
    static FileInputStream fileInputStream;

    static {
        try {
            fileInputStream = new FileInputStream(path);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    static XSSFWorkbook workbook;

    static {
        try {
            workbook = new XSSFWorkbook(fileInputStream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    static XSSFSheet mainSheet = workbook.getSheet("Main");
    static String baseUrl = "http://localhost:5050/City/";

    public MainClass() throws IOException {
    }

    public static void main(String[] args) {

        int rows = mainSheet.getLastRowNum();
        for (int i = 1; i <= rows; i++) {
            String endPoint = String.valueOf(mainSheet.getRow(i).getCell(0));
            if (endPoint.equals("Mumbai") || endPoint.equals("Delhi")) {
                System.out.println(endPoint);
                gts.mainSheetRow = i;
                gts.goToSheetDetails();
//                capiM.endPoint = endPoint;
            }
        }
    }
}
