package QEFramework.Testing2;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.junit.jupiter.api.Test;

import static QEFramework.Testing2.MainClass.mainSheet;

public class goToSheet {
    CheckApi capi = new CheckApi();
    public int mainSheetRow;

    public void goToSheetDetails() {
        XSSFCell goTo = mainSheet.getRow(mainSheetRow).getCell(1);
        String goToString = goTo.getStringCellValue();
        String[] tableDetails = goToString.split(":");
        capi.detailsTableName = tableDetails[0];
        capi.rowInDetails = Integer.parseInt(tableDetails[1]);
        capi.assertNow();
        System.out.println("Going in table" + tableDetails[0] + "\n Going in row" + tableDetails[1]);
    }
}
