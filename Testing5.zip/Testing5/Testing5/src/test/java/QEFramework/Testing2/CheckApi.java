package QEFramework.Testing2;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.jupiter.api.Assertions;

import static QEFramework.Testing2.MainClass.baseUrl;
import static QEFramework.Testing2.MainClass.workbook;

public class CheckApi {

    public String endPoint ;
    public String detailsTableName ;
    XSSFSheet dataSheet = workbook.getSheet(detailsTableName);
    public int rowInDetails =1 ;
    int c = 0;

    public void assertNow() {
        Response response = RestAssured.given()
                .when().get(baseUrl + endPoint);

        Assertions.assertEquals(dataSheet.getRow(rowInDetails).getCell(c++).getStringCellValue(), response.jsonPath().getString("cityName"));
        Assertions.assertEquals(dataSheet.getRow(rowInDetails).getCell(c++).getStringCellValue(), response.jsonPath().getString("state"));
        Assertions.assertEquals(dataSheet.getRow(rowInDetails).getCell(c++).getStringCellValue(), response.jsonPath().getString("country"));
    }
}
